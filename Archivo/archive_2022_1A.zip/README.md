## Fundamentos de la Programacion

Profesor: Jose Torres Cárdenas - pcsijost@upc.edu.pe

### Clases

Apuntes de las clases:

1. [Clase 2: Programación básica (19-03-2022)](/Clases/19032022.md)
2. [Clase 3: Métodos y Selectivas  (26-03-2022)](/Clases/26032022.md)
3. [Clase 4: Iterativas (02-04-2022)](/Clases/02042022.md)
4. [Clase 5: Repaso Iterativas + Arreglos (09-04-2022)](/Clases/09042022.md)
5. [Clase 6: Ejercicios de Arreglos (16-04-2022)](/Clases/16042022.md)
6. [Clase 7: Ejercicios de Arreglos + arreglos multidimensionales (23-04-2022)](/Clases/23042022.md)
7. [Clase 8: Ejercicios de Cadenas (30-04-2022)](/Clases/30042022.md)
8. [Clase 9: Repaso Examen Final (07-05-2022)](/Clases/07052022.md)

